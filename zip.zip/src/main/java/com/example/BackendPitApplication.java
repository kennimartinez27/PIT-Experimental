package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendPitApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendPitApplication.class, args);
	}

}
